
var exports = window;
exports.require = window["ScalaJSBundlerLibrary"].require;
    