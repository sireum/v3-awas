module.exports = {
  "require": (function(x0) {
    return {}[x0]
  })
}