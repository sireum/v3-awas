module.exports = {
  "require": (function(x70) {
    return {}[x70]
  })
}